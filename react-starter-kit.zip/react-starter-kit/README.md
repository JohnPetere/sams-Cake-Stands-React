# React Starter Kit

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

# Scripts

__Development Build__ 
> ```npm start``` 
> Run the following command from your terminal. 
> Starts development server automatically.  
> Open browser to  [http://localhost:3000](http://localhost:3000)  
> project. 

 
 __Production Build__ 
> ```npm run build``` 
> Builds the app for production. 
> Optimizes the build for the best performance.  
> Open browser to  [http://localhost:3000](http://localhost:3000)  
> For more information on [deployments](https://facebook.github.io/create-react-app/docs/deployment). 

 

 

 

 