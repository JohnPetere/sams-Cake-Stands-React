# Component Basics

## What Is A Component
reusable UI element 

## Button Component
- closed/open component.
- props data for sent to the component.
- style comp  css modules.

## Best Practices
1. Components should be inside a folder called funily enough components
1. Naming component file should be upper case first letter.